#include "raylib.h"

float x=250.0f, y=700.0f, carsx[100], carsy[100];int n, signs[100],won;
const float width=500,height=750, player_size=25.0f;
bool run=1;

void Movement()
{
    if(IsKeyDown(KEY_W) && y>=player_size) y-=.05f;
    if(IsKeyDown(KEY_S) && y<=height-player_size) y+=.05f;
    if(IsKeyDown(KEY_A) && x>=player_size) x-=.05f;
    if(IsKeyDown(KEY_D) && x<=width-player_size) x+=.05f; 
    
    
    int i;
    for(i=1;i<=n;i++){
        carsx[i]+=.1f*signs[i];
        
        if(carsx[i]>width) carsx[i]=1.0f;
        
        if(carsx[i]<0) carsx[i]=width;
        
        if(carsx[i]>x-player_size && carsx[i]<x+player_size && carsy[i]>y-player_size && carsy[i]<y+player_size ) run=0;
    }
}

void DefineCar(int cx, int cy, int sign)
{
    carsx[++n]=cx;
    carsy[n]=cy;
    signs[n]=sign;
}

void Drawing()
{
    int i=0;
    while(carsx[++i]!=.0f)
        DrawCircle(carsx[i], carsy[i], 15.0f, RED); 
    
    for(i=1;i<=750;i+=74){
        if(i%2==0){
        DrawCircle(i, 0, 45, BLACK);
        i++;
        }
        else{
        DrawCircle(i, 0, 45, WHITE);
        i--;}
    }
    
}


int main(void)
{
    InitWindow(width, height, "Test");

    DefineCar(250, 650, 1);
    DefineCar(250, 550,-1);
    DefineCar(250, 450, 1);
    DefineCar(250, 350, -1);
    DefineCar(250, 250, -1);
    DefineCar(250, 150, 1);

    while (!WindowShouldClose())
    {
        
        if(run){
        
            if(y<=65) run=0, won=1;
        
            Movement();
            
            ClearBackground(GREEN);
            
            Drawing();
            
            BeginDrawing();
        
            DrawCircle(x, y, player_size, LIME);
        
            EndDrawing();
        }
        else 
        {   
                if(!won){
                ClearBackground(RAYWHITE);
                
                BeginDrawing();
                DrawText("Game Over", width/2-200, height/2-70, 75, RED);
                
                DrawText("Press ENTER to retry", width/2-200, height/2, 35, RED);
                EndDrawing();
                
                if(IsKeyDown(KEY_ENTER))
                    x=250.0f, y=700.0f, run=1;
                }
            else
            {
                won=0;
                ClearBackground(RAYWHITE);
                
                BeginDrawing();
                DrawText("YOU WON!!!", width/2-200, height/2-70, 75, RED);
                
                DrawText("Press ENTER to retry", width/2-200, height/2, 35, RED);
                EndDrawing();
                
                if(IsKeyDown(KEY_ENTER))
                    x=250.0f, y=700.0f, run=1;
                }
        }
    }
    

    CloseWindow();

    return 0;
}
