#include "raylib.h"

float x=250.0f, y=700.0f, carsx[11], carsy[11], coinx[11], coiny[4], carspeed=5.0f, playerspeed=6.0f;
int signs[100],won,i,score,options,dif=1, noc=5;
const float width=500,height=750, player_size=25.0f;
bool run=1, menu=1,running=1;
Texture2D carmodel, coinmodel;

void Movement()
{
    if(IsKeyDown(KEY_W) && y>=player_size) y-=playerspeed;
    if(IsKeyDown(KEY_S) && y<=height-player_size) y+=playerspeed;
    if(IsKeyDown(KEY_A) && x>=player_size) x-=playerspeed;
    if(IsKeyDown(KEY_D) && x<=width-player_size) x+=playerspeed; 
    
    if(IsKeyDown(KEY_ESCAPE)) menu=1;
    
    
    int i;
    for(i=1;i<=noc;i++){
        carsx[i]+=carspeed*signs[i];
        
        if(carsx[i]>width) carsx[i]=1.0f;
        
        if(carsx[i]<0) carsx[i]=width;
        
        if(carsx[i]>x-player_size && carsx[i]<x+player_size && carsy[i]>y-player_size && carsy[i]<y+player_size ) run=0;
        if(coinx[i]>x-player_size && coinx[i]<x+player_size && coiny[i]>y-player_size && coiny[i]<y+player_size ) score++, coinx[i]=0, coiny[i]=0;
    }
}

void Generate()
{
    for(i=1;i<=noc;i++){
        carsx[i]=GetRandomValue(0, width);
        carsy[i]=GetRandomValue(height-player_size-50, 50);
        signs[i]=GetRandomValue(-3, 3);
        
        if(signs[i]>0) signs[i]=1;
        else if(signs[i]<0) signs[i]=-1;
    }
    
    for(i=1;i<=noc;i++)
    {
        coinx[i]=GetRandomValue(0, width);
        coiny[i]=GetRandomValue(height-player_size-50, 50);
    }
}

void Drawing()
{
    int i=0;
    for(i=1;i<=noc;i++)
        if(signs[i])
            DrawTexture(carmodel, carsx[i]-25, carsy[i]-25, WHITE);
        else
            DrawCircle(carsx[i], carsy[i], 15.0f, BLUE); 
    
    for(i=1;i<=3;i++)
        DrawTexture(coinmodel, coinx[i]-15, coiny[i]-15, WHITE);
    
    for(i=1;i<=750;i+=74){
        if(i%2==0){
        DrawCircle(i, 0, 45, BLACK);
        i++;
        }
        else{
        DrawCircle(i, 0, 45, WHITE);
        i--;}
    }
    
    DrawText(TextFormat("SCORE: %d", score), 1, height-25, 25, BLACK);
}

class Menu
{
    public:
    
    void mainmenu()
    {
        ClearBackground(RAYWHITE);
        
        //TITLE
        DrawText("FROGGER",width/4-100, height/4, 95, RED);
        
        //PLAY BUTTON
        DrawRectangle(width/2 - 80, height/2, 200, 80, LIGHTGRAY);
        DrawText("PLAY",width/2 - 70, height/2+10, 70, BLACK);
        
        //OPTIONS BUTTON
        DrawRectangle(width/2 - 80, height/2+100, 200, 80, LIGHTGRAY);
        DrawText("OPTIONS",width/2 - 70, height/2+120, 40, BLACK);
        
        //QUIT BUTTON
        
        DrawRectangle(width/2 - 80, height/2+200, 200, 80, LIGHTGRAY);
        DrawText("QUIT",width/2 - 65, height/2+210, 70, BLACK);
        
        // Detection
        if(IsMouseButtonDown(MOUSE_BUTTON_LEFT)){
            
            //IS PLAY BUTTON CLICKED?
            if(GetMouseX() >= width/2 - 80 && GetMouseX() <= width/2+110 && GetMouseY() >= height/2 && GetMouseY() <= height/2+80)
                menu=0;
            //IS OPTIONS BUTTON CLICKED?
            if(GetMouseX() >= width/2 - 80 && GetMouseX() <= width/2+110 && GetMouseY() >= height/2+100 && GetMouseY() <= height/2+180)
                options=1;
            //IS QUIT BUTTON CLICKED?
            if(GetMouseX() >= width/2 - 80 && GetMouseX() <= width/2+110 && GetMouseY() >= height/2+200 && GetMouseY() <= height/2+275)
               running=0;
        }
    }
    
    void optsmenu()
    {
        //TITLE
        DrawText("OPTIONS",width/4-100, 10, 95, RED);

        //DISPLAY DIFFICULTY
        
        switch(dif){
            case 0: DrawText("DIFFICULTY:",10, height/4, 45, BLACK);DrawText("EASY",310, height/4, 45, GREEN);break;
            case 1: DrawText("DIFFICULTY:",10, height/4, 45, BLACK);DrawText("NORMAL",310, height/4, 45, ORANGE);break;
            case 2: DrawText("DIFFICULTY:",10, height/4, 45, BLACK);DrawText("HARD",310, height/4, 45, RED);break;
        }
        
        DrawText("CHANGE DIFFICULTY: ", 10, height/4+50, 30, BLACK);
        
        DrawRectangle(10, height/4+105, 130, 40, LIGHTGRAY);
        DrawText("EASY", 10, height/4+105, 45, GREEN);
        
        DrawRectangle(175, height/4+105, 180, 40, LIGHTGRAY);
        DrawText("NORMAL", 175, height/4+105, 45, ORANGE);
        
        
        DrawRectangle(375, height/4+105, 180, 40, LIGHTGRAY);
        DrawText("HARD", 375, height/4+105, 45, RED);
        
        DrawRectangle(10, height-50, 120, 40, LIGHTGRAY);
        DrawText("BACK", 10, height-50, 45, BLACK);
        
        if(IsMouseButtonDown(MOUSE_BUTTON_LEFT)){
        if(GetMouseX() >= 10 && GetMouseX() <= 135 && GetMouseY() >= height/4+105 && GetMouseY() <= height/4+145)
            playerspeed=7.0f, carspeed=3.0f, noc=3, dif=0;
        
        if(GetMouseX() >= 175 && GetMouseX() <= 350 && GetMouseY() >= height/4+105 && GetMouseY() <= height/4+125)
            playerspeed=6.0f, carspeed=5.0f, noc=5, dif=1;
        
        if(GetMouseX() >= 375 && GetMouseX() <= 495 && GetMouseY() >= height/4+105 && GetMouseY() <= height/4+125)
            playerspeed=5.0f, carspeed=7.0f, noc=7, dif=2;
        
        if(GetMouseX() >= 10 && GetMouseX() <= 130 && GetMouseY() >= height-50 && GetMouseY() <= height)
            options=0;
        }
    }
};

int main(void)
{
    InitWindow(width, height, "Frogger");
    
    Menu m;
    
    Texture2D frogmodel = LoadTexture("frog.png");
    carmodel = LoadTexture("car.png");
    coinmodel = LoadTexture("coin.png");
    
    SetTargetFPS(60);
    Generate();
    
    while(running)
    {      

        if(menu)
        {   
            x=250.0f, y=700.0f;
            if(options)
            {
                ClearBackground(RAYWHITE);
                
                BeginDrawing();
                m.optsmenu();
                EndDrawing();
            }
            else
            {
                BeginDrawing();
                m.mainmenu();                
                EndDrawing();
            }
        }
        else if(run){
        
            if(y<=65) run=0, won=1;
        
            Movement();
            
            ClearBackground(GREEN);
            
            Drawing();
            
            BeginDrawing();
        
            DrawTexture(frogmodel, x-25, y-25, WHITE);  
        
            EndDrawing();
        }
        else 
        {   
            Generate();
                if(won==0)
                {
                    
                    score =0;
                    ClearBackground(RAYWHITE);
                    
                    BeginDrawing();
                    DrawText("Game Over", width/2-200, height/2-70, 75, RED);
                    
                    DrawText("Press anything to retry", width/2-215, height/2, 35, RED);
                    EndDrawing();
                    
                    if(GetKeyPressed()!=0)
                        x=250.0f, y=700.0f, run=1;
                }
                else
                {
                    ClearBackground(RAYWHITE);
                    
                    BeginDrawing();
                    DrawText("YOU WON!!!", width/2-200, height/2-70, 75, RED);
                    
                    DrawText("Press anything to continue", width/2-230, height/2, 35, RED);
                    EndDrawing();
                    
                    if(GetKeyPressed()!=0){
                        x=250.0f, y=700.0f, run=1;
                        won=0;
                    }
                }
        }
    }   

    CloseWindow();

    return 0;
}
