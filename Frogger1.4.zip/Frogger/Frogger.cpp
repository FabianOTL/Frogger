#include "raylib.h"

int nos=3, selectedskin=1;

float x=250.0f, y=700.0f, carsx[50], carsy[50], coinx[11], coiny[4], lakex[4],lakey[4],carspeed=5.0f, playerspeed=6.0f;
int signs[100],won,i,j,score,options,dif=1, noc=5,nol;
const float minwidth=500,minheight=750, lakesize=75,initialps=playerspeed;
float width=500, height=750,player_size=25.0f;
bool run=1, menu=1,running=1,fullscreen;
Texture2D carmodel, coinmodel,curentmodel,frog,frog1,frog2,lakemodel;

void Movement()
{
    if(IsKeyDown(KEY_W) && y>=player_size) y-=playerspeed;
    if(IsKeyDown(KEY_S) && y<=height-player_size) y+=playerspeed;
    if(IsKeyDown(KEY_A) && x>=player_size) x-=playerspeed;
    if(IsKeyDown(KEY_D) && x<=width-player_size) x+=playerspeed; 
    
    if(IsKeyDown(KEY_ESCAPE)) menu=1;
    
    
    int i;
    for(i=1;i<=noc;i++)
    {
        if(signs[i]==2)
            carsx[i]+=carspeed;
        else 
            carsx[i]-=carspeed;

        if(carsx[i]>width) carsx[i]=1;
        if(carsx[i]<0) carsx[i]=width;
        
        if(carsx[i]>x-player_size && carsx[i]<x+player_size && carsy[i]>y-player_size && carsy[i]<y+player_size ) run=0;
    }
    playerspeed=initialps;
    
    for(i=1;i<=nol;i++){
         for(j=1;j<=noc;j++)
            if(lakex[i]>carsx[j]-lakesize && lakex[i]<carsx[j]+lakesize && lakey[i]>carsy[j]-lakesize && lakey[i]<carsy[j]+lakesize ){ 
            if(signs[j]==2) carsx[j]=lakex[i]-lakesize, signs[j]=1;
            else carsx[j]=lakex[i]+lakesize, signs[j]=2;
        }
        if(lakex[i]>x-lakesize && lakex[i]<x+lakesize && lakey[i]>y-lakesize && lakey[i]<y+lakesize ) playerspeed=initialps/4;
    }  
      
    for(i=1;i<=3;i++)
        if(coinx[i]>x-player_size && coinx[i]<x+player_size && coiny[i]>y-player_size && coiny[i]<y+player_size ) score++, coinx[i]=0, coiny[i]=0;
}

void Generate()
{
    x=width/2;
    y=height-50/height-50;
    
    for(i=1;i<=noc;i++){
        carsx[i]=GetRandomValue(0, width);
        carsy[i]=GetRandomValue(height-player_size-100, 50);
        signs[i]=GetRandomValue(1, 2);
    }
    
    for(i=1;i<=3;i++)
    {
        coinx[i]=GetRandomValue(0, width);
        coiny[i]=GetRandomValue(height-player_size-50, 50);
    }
    
    nol=GetRandomValue(0, 1);
    
    for(i=1;i<=nol;i++)
    {
        lakex[i]=GetRandomValue(width/4, width/2);
        lakey[i]=GetRandomValue(height-lakesize, lakesize-50);
    }
    
}

void Drawing()
{
    BeginDrawing();
    int i=0;
    for(i=1;i<=noc;i++)
        DrawTexture(carmodel, carsx[i]-player_size, carsy[i]-player_size, WHITE);
    
    for(i=1;i<=nol;i++){
        DrawTexture(lakemodel, lakex[i]-lakesize,lakey[i]-lakesize,BLUE);
    }
    
    for(i=1;i<=3;i++)
        DrawTexture(coinmodel, coinx[i]-15, coiny[i]-15, WHITE);
    
    for(i=1;i<=width;i+=80){
        if(i%2==0){
        DrawCircle(i, 0, 45, BLACK);
        i++;
        }
        else{
        DrawCircle(i, 0, 45, WHITE);
        i--;}
    }
    
    DrawTexture(curentmodel, x-player_size/width-player_size, y-player_size/height-player_size, WHITE);  
    
    DrawText(TextFormat("SCORE: %d", score), 1, height-25, 25, BLACK);
    
    EndDrawing();
}

class Menu
{
    void drawbuttons()
    {
        //DIFFICULTIES
        
        DrawText("CHANGE DIFFICULTY: ", 10/width+10, height/4+50, 30/width+30, BLACK);
        
        DrawRectangle(10/width+10, height/4+105, 130/width+130, 40/width+40, LIGHTGRAY);
        DrawText("EASY", 10/width+10, height/4+105, 45/width+45, GREEN);
        
        DrawRectangle(175/width+175, height/4+105, 180/width+180, 40/width+40, LIGHTGRAY);
        DrawText("NORMAL", 175/width+175, height/4+105, 45/width+45, ORANGE);
        
        DrawRectangle(375/width+375, height/4+105, 120/width+120, 40/width+40, LIGHTGRAY);
        DrawText("HARD", 375/width+375, height/4+105, 45/width+45, RED);
        
        //FULLSCREEN
        
        DrawText("FullScreen", 10/width+10, height/4+160, 45/width+45, BLACK);
        if(!fullscreen)
        DrawRectangle(275/width+275, height/4+160, 40/width+40, 40/height+40, RED);
        else
        DrawRectangle(275/width+275, height/4+160, 40/width+40, 40/height+40, GREEN);
        
        //SKIN SELECTORS 
        
        DrawText("SKIN", 10/width+10, height/2+30, 45/width+45, BLACK);
        
            // Left
            DrawTriangle({200/width+200, height/2+45}, {240/width+240, height/2+60}, {240/width+240, height/2+30}, BLACK);
            
            //The Skin
            DrawTexture(curentmodel, 265/width+265, height/2+20, WHITE);
            
            //Right
            
            DrawTriangle({330/width+330, height/2+30}, {330/width+330, height/2+60}, {370/width+370, height/2+45}, BLACK);
                        
        
        //BACK 
        
        DrawRectangle(10/width+10, height-50, 120, 40/width+40, LIGHTGRAY);
        DrawText("BACK", 10, height-50, 40/width+45, BLACK);
        
    }
    
    void clickbuttons()
    {
        //DIFFICULTIES
            
            if(GetMouseX() >= 10/width+10 && GetMouseX() <= 10/width+10+135/width+135 && GetMouseY() >= height/4+105 && GetMouseY() <= height/4+145/height+145)
            {
                playerspeed=7.0f, carspeed=3.0f, noc=3, dif=0;
                if(fullscreen) noc=10,carspeed=10;
            }
            
            if(GetMouseX() >= 175/width+175 && GetMouseX() <= 175/width+175+350/width+350 && GetMouseY() >= height/4+105 && GetMouseY() <= height/4+125/height+125){
                playerspeed=6.0f, carspeed=5.0f, noc=5, dif=1;
                if(fullscreen) noc=15, carspeed=13;
            }
            
            if(GetMouseX() >= 375/width+375 && GetMouseX() <= 375/width+375+495/width+495 && GetMouseY() >= height/4+105 && GetMouseY() <= height/4+125/height+125){
                playerspeed=5.0f, carspeed=7.0f, noc=7, dif=2;
                if(fullscreen) noc=20, carspeed=16;
            }
            
            //SKIN SELECTOR
            
                //Left
                if(GetMouseX() >= 200/width+200 && GetMouseX() <= 240/width+240 && GetMouseY() >= height/2+30 && GetMouseY() <= height/2+60)
                    selectedskin--;
                
                //Right
                
                if(GetMouseX() >= 330/width+330 && GetMouseX() <= 370/width+370 && GetMouseY() >= height/2+30 && GetMouseY() <= height/2+60)
                    selectedskin++;
                
            if(selectedskin>nos) selectedskin=1;
            if(selectedskin<1) selectedskin=nos;
                
            //BACK 
            
            if(GetMouseX() >= 10/width+10 && GetMouseX() <= 10/width+10+130/width+130 && GetMouseY() >= height-50/height-50 && GetMouseY() <= height)
                options=0;
            
            //FULLSCREEN
            
            if(GetMouseX() >= 275/width+275 && GetMouseX() <=275/width+275+130/width+130 && GetMouseY() >= height/4+160/height+160 && GetMouseY() <= height/4+(160+50)/height+(160+50)){
                if(fullscreen){
                    fullscreen=0;
                    ToggleFullscreen();
                    SetWindowSize(minwidth, minheight);
                    width=minwidth;
                    height=minheight;
                    player_size=500.0f;
                    
                    if(dif==0) noc=3;
                    else if(dif==1) noc=5;
                    else noc=7;
                    
                    Generate();                   
                }
                else {
                    fullscreen=1; 
                    SetWindowSize(GetMonitorWidth(GetCurrentMonitor()), GetMonitorHeight(GetCurrentMonitor())); 
                    
                    width=GetMonitorWidth(GetCurrentMonitor());
                    height=GetMonitorHeight(GetCurrentMonitor());
                    player_size=25;
                    
                    if(dif==0) noc=15, carspeed=8;
                    else if(dif==1) noc=20, carspeed=13;
                    else noc=23, carspeed=16;
                    
                    ToggleFullscreen();
                    Generate();
                }
            }
    }
    
    public:
    
    void mainmenu()
    {
        ClearBackground(RAYWHITE);
        
        //TITLE
        DrawText("FROGGER",width/2-220/width-220, height/4, 95, RED);
        
        //PLAY BUTTON
        DrawRectangle(width/2 - 80, height/2, 200, 80, LIGHTGRAY);
        DrawText("PLAY",width/2 - 70, height/2+10, 70, BLACK);
        
        //OPTIONS BUTTON
        DrawRectangle(width/2 - 80, height/2+100, 200, 80, LIGHTGRAY);
        DrawText("OPTIONS",width/2 - 70, height/2+120, 40, BLACK);
        
        //QUIT BUTTON
        
        DrawRectangle(width/2 - 80, height/2+200, 200, 80, LIGHTGRAY);
        DrawText("QUIT",width/2 - 65, height/2+210, 70, BLACK);
        
        // Detection
        if(IsMouseButtonPressed(MOUSE_BUTTON_LEFT)){
            
            //IS PLAY BUTTON CLICKED?
            if(GetMouseX() >= width/2 - 80 && GetMouseX() <= width/2+110 && GetMouseY() >= height/2 && GetMouseY() <= height/2+80)
                menu=0;
            //IS OPTIONS BUTTON CLICKED?
            if(GetMouseX() >= width/2 - 80 && GetMouseX() <= width/2+110 && GetMouseY() >= height/2+100 && GetMouseY() <= height/2+180)
                options=1;
            //IS QUIT BUTTON CLICKED?
            if(GetMouseX() >= width/2 - 80 && GetMouseX() <= width/2+110 && GetMouseY() >= height/2+200 && GetMouseY() <= height/2+275)
               running=0;
        }
    }
    
    void optsmenu()
    {
        //TITLE
        DrawText("OPTIONS",width/4-100, 10, 95, RED);

        //DISPLAY DIFFICULTY
        
        switch(dif){
            case 0: DrawText("DIFFICULTY:",10, height/4, 45, BLACK);DrawText("EASY",310/width+310, height/4, 45, GREEN);break;
            case 1: DrawText("DIFFICULTY:",10, height/4, 45, BLACK);DrawText("NORMAL",310/width+310, height/4, 45, ORANGE);break;
            case 2: DrawText("DIFFICULTY:",10, height/4, 45, BLACK);DrawText("HARD",310/width+310, height/4, 45, RED);break;
        }
        
        drawbuttons();
        
        if(IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
            clickbuttons();
        
        switch(selectedskin){
        case 1: curentmodel=frog;break;
        case 2: curentmodel=frog1;break;
        case 3: curentmodel=frog2;break;
        }
    }
};

int main(void)
{
    InitWindow(width, height, "Frogger");
    
    Menu m;
    
    carmodel = LoadTexture("car.png");
    coinmodel = LoadTexture("coin.png");
    frog = LoadTexture("default.png");
    frog1 = LoadTexture("frog1.png");
    frog2 = LoadTexture("frog2.png");
    lakemodel=LoadTexture("lake.png");
    curentmodel = frog;
    
    SetTargetFPS(60);
    Generate();
    
    while(running)
    {      
        
        if(menu)
        {   
            x=width/2;
            y=height-50/height-50;
            if(options)
            {
                ClearBackground(RAYWHITE);
                
                BeginDrawing();
                m.optsmenu();
                EndDrawing();
            }
            else
            {
                BeginDrawing();
                m.mainmenu();                
                EndDrawing();
            }
        }
        else if(run){
        
            if(y<=65) run=0, won=1;
        
            Movement();
            
            ClearBackground(GREEN);
            
            Drawing();    
        }
        else 
        {   
            Generate();
                if(won==0)
                {
                    
                    score =0;
                    ClearBackground(RAYWHITE);
                    
                    BeginDrawing();
                    DrawText("Game Over", width/2-200/width-200, height/2-70, 75, RED);
                    
                    DrawText("Press anything to retry", width/2-215, height/2, 35, RED);
                    EndDrawing();
                    
                    if(GetKeyPressed()!=0)
                        x=width/2, y=height-50/height-50, run=1;
                }
                else
                {
                    ClearBackground(RAYWHITE);
                    
                    BeginDrawing();
                    DrawText("YOU WON!!!", width/2-200, height/2-70, 75, RED);
                    
                    DrawText("Press anything to continue", width/2-230, height/2, 35, RED);
                    EndDrawing();
                    
                    if(GetKeyPressed()!=0){
                        x=width/2;
                        y=height-50/height-50;
                        run=1;
                        won=0;
                    }
                }
                
        }
    }   

    CloseWindow();

    return 0;
}
